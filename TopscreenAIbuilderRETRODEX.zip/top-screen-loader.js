/**
 * RETRODEX — top-screen-loader.js
 *
 * Gère le chargement des illustrations pour le top-screen (carte jeu).
 * Chaîne de priorité stricte :
 *   1. assets/generated_ai/{gameId}.webp   ← AI-generated (priorité absolue)
 *   2. assets/generated_ai/{gameId}.jpg
 *   3. assets/covers/{gameId}.jpg
 *   4. assets/covers/{gameId}.png
 *   5. Placeholder SVG inline (aucune image générée par code)
 *
 * RÈGLE : aucune image dessinée par canvas ou SVG path complexe.
 * Le placeholder est un SVG simple avec le nom du jeu — pas une illustration.
 *
 * Usage:
 *   TopScreenLoader.load(gameId, imgElement);
 *   TopScreenLoader.loadCard(gameData, cardElement);
 *   TopScreenLoader.preloadBatch(gameIds);
 */

const TopScreenLoader = (() => {

  // ─── CONFIG ───────────────────────────────────────────────────────────────

  const CHAIN = [
    id => `assets/generated_ai/${id}.webp`,
    id => `assets/generated_ai/${id}.jpg`,
    id => `assets/covers/${id}.jpg`,
    id => `assets/covers/${id}.png`
  ];

  const CACHE          = new Map();   // gameId → resolved URL string
  const PENDING        = new Map();   // gameId → Promise (évite double-fetch)
  const PLACEHOLDER_NS = 'http://www.w3.org/2000/svg';

  // ─── LOAD PRINCIPAL ───────────────────────────────────────────────────────

  /**
   * Charge la meilleure image disponible pour un gameId dans un <img>.
   *
   * @param {string}      gameId      - ex. "PS1-001"
   * @param {HTMLElement} imgEl       - L'élément <img> cible
   * @param {Object}      [meta]      - { title, console, genre } pour le placeholder
   * @returns {Promise<'ai'|'cover'|'placeholder'>} Source utilisée
   */
  async function load(gameId, imgEl, meta = {}) {
    if (!imgEl) return 'placeholder';

    // Marque l'image comme en chargement
    imgEl.classList.add('rdx-loading');
    imgEl.removeAttribute('src');

    const url    = await resolveUrl(gameId);
    const source = _detectSource(url, gameId);

    if (url) {
      _applyImage(imgEl, url, gameId, source);
    } else {
      _applyPlaceholder(imgEl, gameId, meta);
    }

    imgEl.classList.remove('rdx-loading');
    return source;
  }

  // ─── LOAD CARTE COMPLÈTE ──────────────────────────────────────────────────

  /**
   * Charge le top-screen d'une carte jeu complète.
   * Cherche un <img class="rdx-cover"> dans cardElement.
   *
   * @param {Object}      gameData    - { id, title, console, genre, ... }
   * @param {HTMLElement} cardElement - L'élément .rdx-card
   * @returns {Promise<void>}
   */
  async function loadCard(gameData, cardElement) {
    const imgEl = cardElement?.querySelector('.rdx-cover, .rdx-top-img, img[data-game-id]');
    if (!imgEl) return;

    const source = await load(gameData.id, imgEl, {
      title   : gameData.title,
      console : gameData.console || gameData.platform,
      genre   : gameData.genre
    });

    // Badge source sur la carte (optionnel — classe CSS)
    cardElement.classList.remove('has-ai', 'has-cover', 'has-placeholder');
    cardElement.classList.add(
      source === 'ai'          ? 'has-ai'          :
      source === 'cover'       ? 'has-cover'        :
                                 'has-placeholder'
    );

    // Data attribute pour debug / CSS
    imgEl.dataset.assetSource = source;
    imgEl.dataset.gameId      = gameData.id;
  }

  // ─── RESOLVE URL ──────────────────────────────────────────────────────────

  /**
   * Résout l'URL de la meilleure image disponible pour un gameId.
   * Avec cache + dédoublonnage des requêtes parallèles.
   *
   * @param {string} gameId
   * @returns {Promise<string|null>}
   */
  async function resolveUrl(gameId) {
    // Cache hit
    if (CACHE.has(gameId)) return CACHE.get(gameId);

    // Requête en cours — partage la même Promise
    if (PENDING.has(gameId)) return PENDING.get(gameId);

    const promise = _probeChain(gameId).then(url => {
      CACHE.set(gameId, url);
      PENDING.delete(gameId);
      return url;
    });

    PENDING.set(gameId, promise);
    return promise;
  }

  /**
   * Parcourt la chaîne CHAIN et retourne la première URL qui répond 200.
   * HEAD request uniquement — ne télécharge pas l'image.
   *
   * @param {string} gameId
   * @returns {Promise<string|null>}
   */
  async function _probeChain(gameId) {
    for (const urlFn of CHAIN) {
      const url = urlFn(gameId);
      try {
        const resp = await fetch(url, { method: 'HEAD' });
        if (resp.ok) return url;
      } catch {
        // Offline / CORS — continue
      }
    }
    return null; // Aucun asset disponible → placeholder
  }

  // ─── APPLY IMAGE ──────────────────────────────────────────────────────────

  /**
   * Applique une URL résolue à un <img> avec gestion d'erreur.
   */
  function _applyImage(imgEl, url, gameId, source) {
    imgEl.onload = () => {
      imgEl.classList.add('rdx-loaded');
      imgEl.classList.remove('rdx-error');
    };
    imgEl.onerror = () => {
      // L'image a répondu 200 HEAD mais échoue au load — placeholder
      console.warn(`[TopScreenLoader] Load error: ${url}`);
      CACHE.delete(gameId); // Invalide le cache
      imgEl.classList.add('rdx-error');
      _applyPlaceholder(imgEl, gameId, {});
    };
    imgEl.src = url;

    if (source === 'ai') {
      imgEl.setAttribute('data-ai-generated', 'true');
    }
  }

  /**
   * Applique un placeholder SVG inline minimal.
   * Simple rectangle avec label — pas d'illustration dessinée.
   *
   * @param {HTMLImageElement} imgEl
   * @param {string} gameId
   * @param {Object} meta - { title, console }
   */
  function _applyPlaceholder(imgEl, gameId, meta) {
    const label      = meta.title    || gameId;
    const consoleLbl = meta.console  || '';
    const svg        = _buildPlaceholderSVG(label, consoleLbl);
    const dataUrl    = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;

    imgEl.src = dataUrl;
    imgEl.classList.add('rdx-placeholder');
    imgEl.setAttribute('data-asset-source', 'placeholder');
    imgEl.setAttribute('alt', label);
  }

  /**
   * SVG placeholder minimal — fond sombre, titre centré.
   * Pas d'illustration, pas de canvas — juste du texte.
   */
  function _buildPlaceholderSVG(title, consoleLabel) {
    const safeTitle   = _xmlEscape(title);
    const safeConsole = _xmlEscape(consoleLabel);
    const words       = safeTitle.split(' ');

    // Découpe le titre sur 2 lignes max si long
    const mid    = Math.ceil(words.length / 2);
    const line1  = words.slice(0, mid).join(' ');
    const line2  = words.slice(mid).join(' ');

    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="400" height="300">
  <rect width="400" height="300" fill="#1a1c14"/>
  <rect x="1" y="1" width="398" height="298" fill="none" stroke="#4a5240" stroke-width="1" stroke-dasharray="4 3"/>
  <text x="200" y="${line2 ? '126' : '140'}"
    font-family="'Press Start 2P', monospace, sans-serif"
    font-size="${safeTitle.length > 20 ? '11' : '13'}"
    fill="#8a9a6a"
    text-anchor="middle"
    dominant-baseline="middle">${line1}</text>
  ${line2 ? `<text x="200" y="150"
    font-family="'Press Start 2P', monospace, sans-serif"
    font-size="${safeTitle.length > 20 ? '11' : '13'}"
    fill="#8a9a6a"
    text-anchor="middle"
    dominant-baseline="middle">${line2}</text>` : ''}
  ${safeConsole ? `<text x="200" y="198"
    font-family="monospace, sans-serif"
    font-size="10"
    fill="#5a6a4a"
    text-anchor="middle">${safeConsole}</text>` : ''}
  <text x="200" y="260"
    font-family="monospace, sans-serif"
    font-size="9"
    fill="#3a4a30"
    text-anchor="middle">NO AI ASSET — GENERATE</text>
</svg>`;
  }

  // ─── PRÉCHARGEMENT BATCH ──────────────────────────────────────────────────

  /**
   * Précharge en arrière-plan les URLs d'un tableau de gameIds.
   * Remplit le cache sans toucher au DOM.
   *
   * @param {string[]} gameIds
   * @param {Function} [onProgress] - callback(done, total)
   * @returns {Promise<Map<string, string|null>>} gameId → url|null
   */
  async function preloadBatch(gameIds, onProgress = null) {
    const results = new Map();
    let done = 0;

    // Batch de 6 requêtes en parallèle max
    const chunks = _chunk(gameIds, 6);
    for (const chunk of chunks) {
      const batch = await Promise.all(
        chunk.map(id => resolveUrl(id).then(url => ({ id, url })))
      );
      for (const { id, url } of batch) {
        results.set(id, url);
      }
      done += chunk.length;
      if (onProgress) onProgress(done, gameIds.length);
    }

    return results;
  }

  // ─── MISE À JOUR POST-GÉNÉRATION ──────────────────────────────────────────

  /**
   * Force le rechargement d'un gameId (après génération d'un nouvel asset AI).
   * Invalide le cache et met à jour tous les <img> matchants dans le DOM.
   *
   * @param {string} gameId
   */
  async function refresh(gameId) {
    CACHE.delete(gameId);
    PENDING.delete(gameId);

    // Invalide aussi le validator global si présent
    if (window.RDX_AssetValidator) {
      window.RDX_AssetValidator.clearCache();
    }

    // Rechargement de toutes les images avec ce gameId dans le DOM
    const imgEls = document.querySelectorAll(`img[data-game-id="${gameId}"]`);
    for (const imgEl of imgEls) {
      const meta = {
        title   : imgEl.dataset.title   || '',
        console : imgEl.dataset.console || ''
      };
      await load(gameId, imgEl, meta);
    }

    console.log(`[TopScreenLoader] Refreshed: ${gameId}`);
  }

  /**
   * Refresh de toute la page — utile après un batch de génération complet.
   */
  async function refreshAll() {
    CACHE.clear();
    PENDING.clear();

    const imgEls = document.querySelectorAll('img[data-game-id]');
    const unique = [...new Set([...imgEls].map(el => el.dataset.gameId))];

    for (const gameId of unique) {
      await refresh(gameId);
    }

    console.log(`[TopScreenLoader] Refreshed all (${unique.length} assets)`);
  }

  // ─── STATS & DEBUG ────────────────────────────────────────────────────────

  /**
   * Stats sur le cache courant.
   */
  function getCacheStats() {
    const ai    = [...CACHE.values()].filter(u => u?.includes('generated_ai')).length;
    const cover = [...CACHE.values()].filter(u => u && !u.includes('generated_ai')).length;
    const miss  = [...CACHE.values()].filter(u => u === null).length;
    return {
      total_cached : CACHE.size,
      ai_assets    : ai,
      cover_assets : cover,
      missing      : miss,
      pending      : PENDING.size
    };
  }

  /**
   * Identifie la source depuis une URL résolue.
   */
  function _detectSource(url, gameId) {
    if (!url) return 'placeholder';
    if (url.includes('generated_ai')) return 'ai';
    return 'cover';
  }

  // ─── UTILS ────────────────────────────────────────────────────────────────

  function _xmlEscape(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function _chunk(arr, n) {
    const result = [];
    for (let i = 0; i < arr.length; i += n) result.push(arr.slice(i, i + n));
    return result;
  }

  // ─── PUBLIC API ───────────────────────────────────────────────────────────

  return {
    load,
    loadCard,
    resolveUrl,
    preloadBatch,
    refresh,
    refreshAll,
    getCacheStats
  };

})();

// ─── GLOBAL ───────────────────────────────────────────────────────────────────

window.TopScreenLoader = TopScreenLoader;
console.log('[TopScreenLoader] ✓ Ready — priorité: generated_ai/ > covers/ > placeholder SVG');
