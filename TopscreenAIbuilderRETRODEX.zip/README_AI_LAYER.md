# RETRODEX — Couche AI Illustrations
## `script/ai/` — Integration Guide

---

## Structure des fichiers

```
prototype_v2/
│
├── script/
│   └── ai/
│       ├── style-bible.json      ← ADN visuel : palettes, styles, eras, consoles, genres
│       ├── game-fiches.json      ← Seeds par jeu : subject, mood, key_elements (52 fiches)
│       ├── prompt-builder.js     ← Assemble prompt final (positive + negative)
│       └── validate-asset.js     ← Audit assets/generated_ai/ via fetch HEAD
│
├── top-screen-loader.js          ← Loader prioritaire AI > covers > placeholder SVG
│
└── assets/
    ├── generated_ai/             ← ← ← DÉPOSER LES IMAGES ICI (WebP prioritaire)
    │   └── .gitkeep
    └── covers/                   ← Fallback covers existants
```

---

## Inclusion dans index.html

```html
<!-- Dans <head> ou avant </body> -->
<script src="top-screen-loader.js"></script>
<script src="script/ai/validate-asset.js"></script>
<script src="script/ai/prompt-builder.js"></script>
```

> `style-bible.json` et `game-fiches.json` sont chargés en fetch() par `prompt-builder.js`.  
> Pas besoin de les inclure en `<script>`.

---

## Utilisation — Chargement image

### 1. Sur un `<img>` direct
```js
// Dans tes modules JS existants (retrodex.js, market.js...)
const imgEl = document.querySelector('.rdx-cover');
await TopScreenLoader.load('PS1-001', imgEl, {
  title: 'Final Fantasy VII',
  console: 'PS1',
  genre: 'rpg'
});
```

### 2. Sur une carte complète
```js
// La carte doit contenir un <img class="rdx-cover">
const card = document.querySelector('.rdx-card');
await TopScreenLoader.loadCard(gameData, card);
// → Ajoute class has-ai / has-cover / has-placeholder sur la carte
```

### 3. Préchargement batch au démarrage
```js
// Au init de retrodex.js — avant affichage des cartes
const gameIds = window.CATALOG_DATA.map(g => g.id);
await TopScreenLoader.preloadBatch(gameIds, (done, total) => {
  console.log(`Preload: ${done}/${total}`);
});
```

---

## Utilisation — Génération de prompts

### Prompt unique (Midjourney)
```js
const builder = await createPromptBuilder();

// Prompt Midjourney complet
const mjPrompt = builder.getMidjourneyPrompt('PS1-001');
// → "lone armored space hero in dystopian city, ... --ar 4:3 --q 2 --style raw"

// Objet complet
const prompt = builder.buildPrompt('PS1-001');
console.log(prompt.positive);  // Prompt positif
console.log(prompt.negative);  // Prompt négatif
console.log(prompt.filename);  // "PS1-001.webp"
```

### Batch export (Midjourney / DALL-E / SDXL)
```js
const entries = window.CATALOG_DATA; // [{ id, console, genre, title }, ...]
const builder = await createPromptBuilder();

// Markdown lisible — paste dans Notion
const md = builder.exportBatchMarkdown(entries);

// TSV — paste dans Google Sheets
const tsv = builder.exportBatchTSV(entries);

// JSON machine — pour script externe
const json = builder.exportBatchJSON(entries);
```

### Prompt DALL-E 3
```js
const { prompt } = builder.getDallePrompt('N64-001');
// Negative intégrée dans le positive (DALL-E ne supporte pas negative direct)
```

---

## Utilisation — Audit des assets

### Vérifier un asset
```js
const result = await RDX_AssetValidator.validateAsset('PS1-001');
// → { found: true, path: 'assets/generated_ai/PS1-001.webp', source: 'ai', status: 'ok' }
// → { found: false, path: null, source: 'covers', fallback: 'assets/covers/PS1-001.jpg', status: 'fallback' }
// → { found: false, path: null, source: 'none', fallback: null, status: 'missing' }
```

### Audit complet du catalogue
```js
const gameIds = window.CATALOG_DATA.map(g => g.id);
const report  = await RDX_AssetValidator.auditCatalog(gameIds, (done, total) => {
  console.log(`${done}/${total}`);
});

RDX_AssetValidator.logReport();
// ✅ AI ready   : 23 (48%)
// 🟡 Fallback   : 12
// ❌ Missing    : 13

// Télécharge la liste des manquants (pour batch generation)
RDX_AssetValidator.downloadMissingList();
```

---

## Workflow de génération recommandé

```
1. Lancer l'audit
   → auditCatalog(allGameIds)
   → downloadMissingList()          ← liste .txt des IDs à générer

2. Pour chaque ID manquant :
   → builder.getMidjourneyPrompt(id)  ← copier dans Midjourney
   → Nommer le fichier {gameId}.webp
   → Déposer dans assets/generated_ai/

3. Après génération batch :
   → TopScreenLoader.refreshAll()    ← invalide cache + reload DOM
   → RDX_AssetValidator.auditCatalog() ← nouveau rapport
```

---

## Format des assets

| Format | Résolution | Recommandé |
|--------|-----------|------------|
| WebP   | 800×600   | ✅ Priorité 1 |
| WebP   | 600×600   | ✅ Cartes carrées |
| JPG    | 800×600   | 🟡 Fallback |
| PNG    | Toute     | 🟡 Fallback |

**Naming strict : `{gameId}.webp`** — ex. `PS1-001.webp`, `N64-003.webp`

---

## CSS recommandé pour top-screen

```css
/* État de chargement */
.rdx-cover.rdx-loading {
  opacity: 0;
  transition: opacity 0.3s;
}
.rdx-cover.rdx-loaded {
  opacity: 1;
}

/* Badge source */
.rdx-card.has-ai .rdx-cover::after {
  content: 'AI';
  /* badge vert discret */
}
.rdx-card.has-placeholder .rdx-cover {
  filter: grayscale(0.3);
}
```

---

## Globals exposés

| Global | Type | Description |
|--------|------|-------------|
| `TopScreenLoader` | Object | Loader AI > covers > placeholder |
| `RDX_AssetValidator` | AssetValidator | Singleton audit |
| `AssetValidator` | Class | Pour instances custom |
| `PromptBuilder` | Class | Pour instances custom |
| `createPromptBuilder()` | async fn | Factory — charge JSON + instancie |
