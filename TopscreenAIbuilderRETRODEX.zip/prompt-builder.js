/**
 * RETRODEX — prompt-builder.js
 * Couche script/ai/
 *
 * Assemble les prompts AI pour la génération d'illustrations de jeux.
 * Combine style-bible.json + game-fiches.json → prompts finaux prêts à copier.
 *
 * Usage:
 *   const builder = new PromptBuilder(styleBible, gameFiches);
 *   const prompt  = builder.buildPrompt('PS1-001');
 *   const batch   = builder.buildBatchManifest(entries);
 *
 * Aucune image générée ici — outputs sont des strings de texte pour engines externes
 * (Midjourney, DALL-E 3, Stable Diffusion XL, etc.)
 */

class PromptBuilder {
  /**
   * @param {Object} styleBible  - Parsed style-bible.json
   * @param {Object} gameFiches  - Parsed game-fiches.json
   */
  constructor(styleBible, gameFiches) {
    this.bible    = styleBible;
    this.fiches   = gameFiches.fiches;
    this.fallback = gameFiches.fallback_fiche;
  }

  // ─── CORE BUILD ───────────────────────────────────────────────────────────

  /**
   * Construit le prompt complet pour un jeu donné.
   * @param {string} gameId   - ex. "PS1-001"
   * @param {Object} [meta]   - optionnel: { consoleId, genre, title } si pas dans fiche
   * @returns {{ positive: string, negative: string, filename: string, metadata: Object }}
   */
  buildPrompt(gameId, meta = {}) {
    const fiche   = this.fiches[gameId] || null;
    const consoleId = fiche?.console || meta.consoleId || this._guessConsole(gameId);
    const genre     = fiche?.genre   || meta.genre     || 'action';
    const title     = fiche?.title   || meta.title     || gameId;

    const consoleDef = this.bible.consoles[consoleId] || null;
    const eraDef     = consoleDef ? this.bible.eras[consoleDef.era] : null;
    const genreDef   = this.bible.genres[genre] || this.bible.genres['action'];

    const positive = this._assemblePositive(fiche, consoleDef, eraDef, genreDef);
    const negative = this._assembleNegative();
    const filename = `${gameId}.webp`;

    return {
      gameId,
      title,
      console: consoleId,
      genre,
      positive,
      negative,
      filename,
      target_path: `assets/generated_ai/${filename}`,
      metadata: {
        era: eraDef?.label || 'Unknown Era',
        aspect_ratio: this.bible.global.aspect_ratio,
        resolution: this.bible.global.resolution,
        quality_suffix: this.bible.global.quality_suffix,
        engine_note: 'Tested: Midjourney v6, DALL-E 3, SDXL'
      }
    };
  }

  // ─── ASSEMBLAGE POSITIF ───────────────────────────────────────────────────

  _assemblePositive(fiche, consoleDef, eraDef, genreDef) {
    const parts = [];

    // 1. Base globale
    parts.push(...this.bible.global.positive_base);

    // 2. Style era
    if (eraDef?.style_tokens) {
      parts.push(...eraDef.style_tokens);
    }

    // 3. Style console
    if (consoleDef?.style_hint) {
      parts.push(consoleDef.style_hint);
    }
    if (consoleDef?.extra_tokens) {
      parts.push(...consoleDef.extra_tokens);
    }

    // 4. Genre composition
    if (genreDef?.composition_hints) {
      parts.push(...genreDef.composition_hints);
    }
    if (genreDef?.mood) {
      parts.push(genreDef.mood);
    }

    // 5. Fiche spécifique (priorité maximale)
    const activeFiche = fiche || this.fallback;
    if (activeFiche.subject) {
      parts.unshift(activeFiche.subject); // subject en tête
    }
    if (activeFiche.key_elements) {
      parts.push(...activeFiche.key_elements);
    }
    if (activeFiche.composition_override) {
      parts.push(activeFiche.composition_override);
    }
    if (activeFiche.mood_override) {
      parts.push(activeFiche.mood_override);
    }
    if (activeFiche.era_style) {
      parts.push(activeFiche.era_style);
    }

    // 6. Palette console
    if (consoleDef?.palette) {
      parts.push(`color palette: ${consoleDef.palette}`);
    }

    return this._dedup(parts).join(', ');
  }

  // ─── ASSEMBLAGE NÉGATIF ───────────────────────────────────────────────────

  _assembleNegative() {
    return this.bible.global.negative_base.join(', ');
  }

  // ─── BATCH MANIFEST ───────────────────────────────────────────────────────

  /**
   * Génère un manifest batch pour un ensemble de jeux.
   * Output JSON prêt à être traité par un script de génération externe.
   *
   * @param {Array} entries - Array de { id, console, genre, title }
   * @returns {Object} manifest complet
   */
  buildBatchManifest(entries) {
    const timestamp = new Date().toISOString().slice(0, 16).replace('T', '_').replace(':', 'h');
    const jobs      = [];
    const errors    = [];

    for (const entry of entries) {
      try {
        const prompt = this.buildPrompt(entry.id, {
          consoleId : entry.console,
          genre     : entry.genre,
          title     : entry.title
        });
        jobs.push({
          job_id      : entry.id,
          title       : prompt.title,
          filename    : prompt.filename,
          target_path : prompt.target_path,
          positive    : prompt.positive,
          negative    : prompt.negative,
          aspect_ratio: prompt.metadata.aspect_ratio,
          resolution  : prompt.metadata.resolution,
          status      : 'pending'
        });
      } catch (e) {
        errors.push({ id: entry.id, error: e.message });
      }
    }

    return {
      manifest_version : '1.0',
      generated_at     : timestamp,
      total_jobs       : jobs.length,
      errors_count     : errors.length,
      target_dir       : this.bible.output_naming.target_dir,
      jobs,
      errors
    };
  }

  /**
   * Export manifest batch en JSON string (pour téléchargement ou clipboard).
   * @param {Array} entries
   * @returns {string} JSON formaté
   */
  exportBatchJSON(entries) {
    return JSON.stringify(this.buildBatchManifest(entries), null, 2);
  }

  /**
   * Export batch en format TSV lisible — une ligne par jeu.
   * Colonnes: gameId | title | console | positive | negative
   * Utile pour copier-coller dans Midjourney ou Google Sheets.
   *
   * @param {Array} entries
   * @returns {string} TSV string
   */
  exportBatchTSV(entries) {
    const manifest = this.buildBatchManifest(entries);
    const header   = ['gameId', 'title', 'filename', 'positive', 'negative'].join('\t');
    const rows     = manifest.jobs.map(j =>
      [j.job_id, j.title, j.filename, j.positive, j.negative].join('\t')
    );
    return [header, ...rows].join('\n');
  }

  /**
   * Export batch en format Markdown — bloc par jeu avec prompts formatés.
   * Pratique pour Notion, obsidian, ou paste directe dans DALL-E web.
   *
   * @param {Array} entries
   * @returns {string} Markdown string
   */
  exportBatchMarkdown(entries) {
    const manifest = this.buildBatchManifest(entries);
    const blocks = manifest.jobs.map(j => [
      `## ${j.job_id} — ${j.title}`,
      `**File:** \`${j.target_path}\``,
      '',
      '**✅ Positive prompt:**',
      '```',
      j.positive,
      '```',
      '',
      '**❌ Negative prompt:**',
      '```',
      j.negative,
      '```',
      '',
      `**Aspect:** ${j.aspect_ratio} — **Resolution:** ${j.resolution.w}×${j.resolution.h}`,
      '',
      '---'
    ].join('\n'));

    return [
      `# RETRODEX AI Batch — ${manifest.generated_at}`,
      `**${manifest.total_jobs} jobs** — Target: \`${manifest.target_dir}\``,
      '',
      ...blocks
    ].join('\n');
  }

  // ─── PROMPT UNIQUE FORMATÉ ────────────────────────────────────────────────

  /**
   * Retourne le prompt positif seul, prêt à copier dans Midjourney.
   * Ajoute le suffix qualité Midjourney si demandé.
   *
   * @param {string} gameId
   * @param {boolean} [withSuffix=true] - Ajouter --ar 4:3 --q 2 etc.
   * @returns {string}
   */
  getMidjourneyPrompt(gameId, withSuffix = true) {
    const { positive, metadata } = this.buildPrompt(gameId);
    if (!withSuffix) return positive;

    const ar = `--ar ${metadata.aspect_ratio.replace(':', ':')}`;
    return `${positive} ${ar} ${metadata.quality_suffix}`;
  }

  /**
   * Retourne un objet simple { positive, negative } pour DALL-E 3.
   * DALL-E n'accepte pas de negative prompt direct — la negative est intégrée
   * dans le positive sous forme "avoid: ..."
   *
   * @param {string} gameId
   * @returns {{ prompt: string }}
   */
  getDallePrompt(gameId) {
    const { positive, negative } = this.buildPrompt(gameId);
    return {
      prompt: `${positive}. Style: do not include ${negative.split(', ').slice(0, 6).join(', ')}.`
    };
  }

  // ─── UTILS ────────────────────────────────────────────────────────────────

  /**
   * Déduplique un tableau de strings (insensible à la casse).
   */
  _dedup(arr) {
    const seen = new Set();
    return arr.filter(item => {
      const key = item.toLowerCase().trim();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  /**
   * Devine le consoleId depuis un gameId comme "PS1-001" → "PS1"
   */
  _guessConsole(gameId) {
    const match = gameId.match(/^([A-Z0-9_]+)-\d+$/);
    return match ? match[1] : 'PS2';
  }

  /**
   * Liste tous les jeux avec fiche disponible.
   * @returns {string[]} Array de gameIds
   */
  getAvailableFiches() {
    return Object.keys(this.fiches);
  }

  /**
   * Vérifie si une fiche existe pour un gameId.
   * @param {string} gameId
   * @returns {boolean}
   */
  hasFiche(gameId) {
    return gameId in this.fiches;
  }

  /**
   * Résumé stats du builder.
   * @returns {Object}
   */
  getStats() {
    const ficheIds   = Object.keys(this.fiches);
    const consoles   = [...new Set(ficheIds.map(id => this._guessConsole(id)))];
    const genreCount = {};
    for (const f of Object.values(this.fiches)) {
      genreCount[f.genre] = (genreCount[f.genre] || 0) + 1;
    }
    return {
      total_fiches    : ficheIds.length,
      consoles_covered: consoles,
      genres_breakdown: genreCount,
      style_bible_eras: Object.keys(this.bible.eras),
      style_bible_consoles: Object.keys(this.bible.consoles)
    };
  }
}

// ─── FACTORY LOADER ──────────────────────────────────────────────────────────
// Charge les JSON et instancie le builder.
// Compatible vanilla JS (no import/export) via window global.

async function createPromptBuilder() {
  try {
    const [bibleResp, fichesResp] = await Promise.all([
      fetch('script/ai/style-bible.json'),
      fetch('script/ai/game-fiches.json')
    ]);

    if (!bibleResp.ok)  throw new Error(`style-bible.json: HTTP ${bibleResp.status}`);
    if (!fichesResp.ok) throw new Error(`game-fiches.json: HTTP ${fichesResp.status}`);

    const bible  = await bibleResp.json();
    const fiches = await fichesResp.json();

    const builder = new PromptBuilder(bible, fiches);
    console.log(`[PromptBuilder] ✓ Loaded — ${builder.getStats().total_fiches} fiches`);
    return builder;

  } catch (e) {
    console.error('[PromptBuilder] ✗ Load failed:', e);
    return null;
  }
}

// Expose global
window.PromptBuilder    = PromptBuilder;
window.createPromptBuilder = createPromptBuilder;
