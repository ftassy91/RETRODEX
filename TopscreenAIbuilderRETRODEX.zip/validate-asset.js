/**
 * RETRODEX — validate-asset.js
 * Couche script/ai/
 *
 * Valide la présence des assets générés par AI dans assets/generated_ai/.
 * Fonctionne en contexte browser (fetch HEAD), pas de dépendance Node/fs.
 *
 * Aucune image générée — audit uniquement.
 *
 * Usage:
 *   const validator = new AssetValidator();
 *   await validator.validateAsset('PS1-001');
 *   await validator.auditCatalog(gameIds);
 *   validator.downloadMissingList();
 */

class AssetValidator {
  /**
   * @param {Object} [options]
   * @param {string} [options.aiDir='assets/generated_ai/']   - Dossier AI (priorité 1)
   * @param {string} [options.coversDir='assets/covers/']     - Fallback covers (priorité 2)
   * @param {string[]} [options.extensions=['.webp','.jpg','.png']]
   * @param {number} [options.concurrency=6]  - Requêtes parallèles max
   */
  constructor(options = {}) {
    this.aiDir      = options.aiDir       ?? 'assets/generated_ai/';
    this.coversDir  = options.coversDir   ?? 'assets/covers/';
    this.extensions = options.extensions  ?? ['.webp', '.jpg', '.png'];
    this.concurrency = options.concurrency ?? 6;

    // Cache résultats pour éviter double-fetch
    this._cache = new Map();

    // Rapport courant
    this.lastReport = null;
  }

  // ─── VALIDATION UNIQUE ────────────────────────────────────────────────────

  /**
   * Vérifie si un asset AI existe pour un gameId.
   * Essaie chaque extension dans l'ordre.
   *
   * @param {string} gameId - ex. "PS1-001"
   * @returns {Promise<AssetResult>}
   *
   * @typedef {Object} AssetResult
   * @property {string}  gameId
   * @property {boolean} found       - Asset AI trouvé dans generated_ai/
   * @property {string|null} path    - Chemin trouvé (null si absent)
   * @property {string}  source      - 'ai' | 'covers' | 'none'
   * @property {string}  fallback    - Prochain fallback disponible
   * @property {string}  status      - 'ok' | 'fallback' | 'missing'
   */
  async validateAsset(gameId) {
    const cacheKey = `asset:${gameId}`;
    if (this._cache.has(cacheKey)) return this._cache.get(cacheKey);

    // 1. Cherche dans assets/generated_ai/
    const aiPath = await this._probeExtensions(this.aiDir, gameId);
    if (aiPath) {
      const result = {
        gameId,
        found    : true,
        path     : aiPath,
        source   : 'ai',
        fallback : aiPath,
        status   : 'ok'
      };
      this._cache.set(cacheKey, result);
      return result;
    }

    // 2. Cherche dans assets/covers/
    const coverPath = await this._probeExtensions(this.coversDir, gameId);
    if (coverPath) {
      const result = {
        gameId,
        found    : false,
        path     : null,
        source   : 'covers',
        fallback : coverPath,
        status   : 'fallback'
      };
      this._cache.set(cacheKey, result);
      return result;
    }

    // 3. Aucun asset
    const result = {
      gameId,
      found    : false,
      path     : null,
      source   : 'none',
      fallback : null,
      status   : 'missing'
    };
    this._cache.set(cacheKey, result);
    return result;
  }

  // ─── AUDIT CATALOGUE ──────────────────────────────────────────────────────

  /**
   * Audit complet d'un tableau de gameIds.
   * Retourne un rapport structuré.
   *
   * @param {string[]} gameIds
   * @param {Function} [onProgress] - callback(done, total, currentId)
   * @returns {Promise<AuditReport>}
   *
   * @typedef {Object} AuditReport
   * @property {number}   total
   * @property {string[]} ai_ready     - Trouvés dans generated_ai/
   * @property {string[]} fallback     - Couverts par assets/covers/
   * @property {string[]} missing      - Aucun asset
   * @property {number}   coverage_pct - % avec AI asset
   * @property {Object}   by_console   - Breakdown par console
   * @property {string}   generated_at - Timestamp
   */
  async auditCatalog(gameIds, onProgress = null) {
    const results = [];
    let done = 0;

    // Traitement par batch pour respecter la concurrence
    const chunks = this._chunk(gameIds, this.concurrency);
    for (const chunk of chunks) {
      const batch = await Promise.all(chunk.map(id => this.validateAsset(id)));
      results.push(...batch);
      done += chunk.length;
      if (onProgress) onProgress(done, gameIds.length, chunk[chunk.length - 1]);
    }

    const aiReady  = results.filter(r => r.status === 'ok').map(r => r.gameId);
    const fallback = results.filter(r => r.status === 'fallback').map(r => r.gameId);
    const missing  = results.filter(r => r.status === 'missing').map(r => r.gameId);

    // Breakdown par console
    const byConsole = {};
    for (const r of results) {
      const consoleId = r.gameId.replace(/-\d+$/, '');
      if (!byConsole[consoleId]) {
        byConsole[consoleId] = { total: 0, ai_ready: 0, fallback: 0, missing: 0 };
      }
      byConsole[consoleId].total++;
      byConsole[consoleId][r.status === 'ok' ? 'ai_ready' : r.status]++;
    }

    const report = {
      total        : gameIds.length,
      ai_ready     : aiReady,
      fallback,
      missing,
      coverage_pct : Math.round((aiReady.length / gameIds.length) * 100),
      by_console   : byConsole,
      generated_at : new Date().toISOString()
    };

    this.lastReport = report;
    return report;
  }

  // ─── RÉSOLUTION ASSET (pour top-screen-loader) ────────────────────────────

  /**
   * Résout le meilleur chemin disponible pour affichage.
   * Version rapide (une seule requête en mode optimiste).
   *
   * @param {string} gameId
   * @returns {Promise<string|null>} Chemin à utiliser, ou null
   */
  async resolveAsset(gameId) {
    const result = await this.validateAsset(gameId);
    return result.fallback || null;
  }

  /**
   * Résout en priorité AI, sans cache (force re-check).
   * Utile après une génération batch.
   *
   * @param {string} gameId
   * @returns {Promise<string|null>}
   */
  async resolveAssetFresh(gameId) {
    this._cache.delete(`asset:${gameId}`);
    return this.resolveAsset(gameId);
  }

  // ─── EXPORT / TÉLÉCHARGEMENT ──────────────────────────────────────────────

  /**
   * Télécharge un fichier texte listant les gameIds sans AI asset.
   * Pour batch de génération externe.
   *
   * @param {AuditReport} [report] - Utilise lastReport si omis
   */
  downloadMissingList(report = null) {
    const r = report || this.lastReport;
    if (!r) {
      console.warn('[AssetValidator] Aucun rapport disponible — lancez auditCatalog() d\'abord.');
      return;
    }

    const content = [
      `# RETRODEX — Missing AI Assets`,
      `# Generated: ${r.generated_at}`,
      `# Total missing: ${r.missing.length} / ${r.total}`,
      `# Coverage: ${r.coverage_pct}%`,
      '',
      '# Paste each gameId into prompt-builder to get the prompt:',
      '',
      ...r.missing.map(id => id)
    ].join('\n');

    this._downloadText(content, `retrodex_missing_assets_${Date.now()}.txt`);
  }

  /**
   * Télécharge le rapport complet en JSON.
   * @param {AuditReport} [report]
   */
  downloadReport(report = null) {
    const r = report || this.lastReport;
    if (!r) return;
    this._downloadText(JSON.stringify(r, null, 2), `retrodex_asset_report_${Date.now()}.json`);
  }

  /**
   * Télécharge un manifest TSV pour batch de génération.
   * Colonnes: gameId | ai_path_target | status
   *
   * @param {string[]} gameIds
   */
  async downloadBatchManifestTSV(gameIds) {
    const report = await this.auditCatalog(gameIds);
    const rows   = [
      ['gameId', 'target_path', 'status'].join('\t'),
      ...report.missing.map(id  => [id, `assets/generated_ai/${id}.webp`, 'MISSING'].join('\t')),
      ...report.fallback.map(id => [id, `assets/generated_ai/${id}.webp`, 'HAS_COVER_ONLY'].join('\t')),
      ...report.ai_ready.map(id => [id, `assets/generated_ai/${id}.webp`, 'OK'].join('\t'))
    ];
    this._downloadText(rows.join('\n'), `retrodex_batch_manifest_${Date.now()}.tsv`);
  }

  // ─── AFFICHAGE RAPPORT (console) ──────────────────────────────────────────

  /**
   * Affiche un résumé du dernier rapport dans la console.
   */
  logReport(report = null) {
    const r = report || this.lastReport;
    if (!r) { console.warn('[AssetValidator] Pas de rapport.'); return; }

    console.group('[AssetValidator] Audit Report');
    console.log(`Total         : ${r.total}`);
    console.log(`✅ AI ready   : ${r.ai_ready.length} (${r.coverage_pct}%)`);
    console.log(`🟡 Fallback   : ${r.fallback.length}`);
    console.log(`❌ Missing    : ${r.missing.length}`);
    console.log('By console:', r.by_console);
    if (r.missing.length > 0) {
      console.warn('Missing IDs:', r.missing.join(', '));
    }
    console.groupEnd();
  }

  // ─── UTILS PRIVÉS ─────────────────────────────────────────────────────────

  /**
   * Probe un dossier pour un gameId avec chaque extension.
   * Utilise fetch HEAD (ne télécharge pas l'image).
   *
   * @param {string} dir
   * @param {string} gameId
   * @returns {Promise<string|null>} Chemin si trouvé, null sinon
   */
  async _probeExtensions(dir, gameId) {
    for (const ext of this.extensions) {
      const path = `${dir}${gameId}${ext}`;
      try {
        const resp = await fetch(path, { method: 'HEAD' });
        if (resp.ok) return path;
      } catch {
        // réseau indisponible ou CORS — skip silencieusement
      }
    }
    return null;
  }

  /**
   * Découpe un tableau en chunks de taille n.
   */
  _chunk(arr, n) {
    const result = [];
    for (let i = 0; i < arr.length; i += n) {
      result.push(arr.slice(i, i + n));
    }
    return result;
  }

  /**
   * Déclenche un téléchargement navigateur.
   */
  _downloadText(content, filename) {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = Object.assign(document.createElement('a'), {
      href     : url,
      download : filename
    });
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Vide le cache de validation.
   */
  clearCache() {
    this._cache.clear();
    console.log('[AssetValidator] Cache cleared.');
  }

  /**
   * Stats sur le cache courant.
   */
  getCacheStats() {
    const entries = [...this._cache.values()];
    return {
      cached    : entries.length,
      ai_ready  : entries.filter(r => r.status === 'ok').length,
      fallback  : entries.filter(r => r.status === 'fallback').length,
      missing   : entries.filter(r => r.status === 'missing').length
    };
  }
}

// ─── SINGLETON GLOBAL ─────────────────────────────────────────────────────────

const RDX_AssetValidator = new AssetValidator();
window.RDX_AssetValidator = RDX_AssetValidator;
window.AssetValidator     = AssetValidator;

console.log('[AssetValidator] ✓ Ready — window.RDX_AssetValidator');
